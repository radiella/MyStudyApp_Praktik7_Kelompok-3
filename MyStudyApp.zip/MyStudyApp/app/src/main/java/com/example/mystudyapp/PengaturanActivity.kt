package com.example.mystudyapp

import android.os.Bundle
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class PengaturanActivity : AppCompatActivity() {

    private lateinit var settings: SettingsManager

    private lateinit var rgBahasa: RadioGroup
    private lateinit var rgTema: RadioGroup
    private lateinit var rgUkuran: RadioGroup
    private lateinit var swNotifikasi: SwitchCompat
    private lateinit var tvRingkasan: TextView
    private lateinit var tvStatusNotifikasi: TextView
    private lateinit var btnReset: Button

    private var isUpdatingUi = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pengaturan)

        settings = SettingsManager(this)

        rgBahasa = findViewById(R.id.rgBahasa)
        rgTema = findViewById(R.id.rgTema)
        rgUkuran = findViewById(R.id.rgUkuran)
        swNotifikasi = findViewById(R.id.swNotifikasi)
        tvRingkasan = findViewById(R.id.tvRingkasan)
        tvStatusNotifikasi = findViewById(R.id.tvStatusNotifikasi)
        btnReset = findViewById(R.id.btnReset)

        setupListeners()
        muatPengaturanKeUI()
    }

    private fun setupListeners() {
        rgBahasa.setOnCheckedChangeListener { _, checkedId ->
            if (isUpdatingUi) return@setOnCheckedChangeListener
            val bahasa = if (checkedId == R.id.rbEnglish) SettingsManager.BAHASA_EN else SettingsManager.BAHASA_ID
            settings.simpanBahasa(bahasa)
            SettingsManager.terapkanKeAplikasi(this)
            perbaruiRingkasan()
        }

        rgTema.setOnCheckedChangeListener { _, checkedId ->
            if (isUpdatingUi) return@setOnCheckedChangeListener
            val tema = if (checkedId == R.id.rbGelap) SettingsManager.TEMA_GELAP else SettingsManager.TEMA_TERANG
            settings.simpanTema(tema)
            SettingsManager.terapkanKeAplikasi(this)
            perbaruiRingkasan()
        }

        rgUkuran.setOnCheckedChangeListener { _, checkedId ->
            if (isUpdatingUi) return@setOnCheckedChangeListener
            val ukuran = when (checkedId) {
                R.id.rbKecil -> SettingsManager.UKURAN_KECIL
                R.id.rbBesar -> SettingsManager.UKURAN_BESAR
                else -> SettingsManager.UKURAN_SEDANG
            }
            settings.simpanUkuran(ukuran)
            perbaruiRingkasan()
        }

        swNotifikasi.setOnCheckedChangeListener { _, isChecked ->
            if (isUpdatingUi) return@setOnCheckedChangeListener
            settings.simpanNotifikasi(isChecked)
            perbaruiRingkasan()
        }

        btnReset.setOnClickListener {
            tampilkanDialogReset()
        }
    }

    private fun muatPengaturanKeUI() {
        isUpdatingUi = true

        when (settings.ambilBahasa()) {
            SettingsManager.BAHASA_EN -> rgBahasa.check(R.id.rbEnglish)
            else -> rgBahasa.check(R.id.rbIndonesia)
        }

        when (settings.ambilTema()) {
            SettingsManager.TEMA_GELAP -> rgTema.check(R.id.rbGelap)
            else -> rgTema.check(R.id.rbTerang)
        }

        when (settings.ambilUkuran()) {
            SettingsManager.UKURAN_KECIL -> rgUkuran.check(R.id.rbKecil)
            SettingsManager.UKURAN_BESAR -> rgUkuran.check(R.id.rbBesar)
            else -> rgUkuran.check(R.id.rbSedang)
        }

        swNotifikasi.isChecked = settings.ambilNotifikasi()

        isUpdatingUi = false

        perbaruiRingkasan()
    }

    private fun perbaruiRingkasan() {
        tvRingkasan.text = RingkasanPengaturan.teks(this, settings)
        tvStatusNotifikasi.text = RingkasanPengaturan.statusNotifikasi(this, settings)
    }

    private fun tampilkanDialogReset() {
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_reset_judul)
            .setMessage(R.string.dialog_reset_pesan)
            .setPositiveButton(R.string.dialog_ya) { _, _ ->
                settings.reset()
                SettingsManager.terapkanKeAplikasi(this)
                muatPengaturanKeUI()
                Toast.makeText(this, R.string.toast_reset, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.dialog_batal, null)
            .show()
    }
}
