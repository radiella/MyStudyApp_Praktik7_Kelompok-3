
package com.example.mystudyapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var settings: SettingsManager
    private lateinit var tvRingkasan: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        settings = SettingsManager(this)
        tvRingkasan = findViewById(R.id.tvRingkasan)

        val btnPengaturan = findViewById<Button>(R.id.btnPengaturan)

        btnPengaturan.setOnClickListener {
            val intent = Intent(this, PengaturanActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onResume() {
        super.onResume()

        if (::settings.isInitialized) {
            val ukuranSp = settings.ukuranTeksSp()
            findViewById<TextView>(R.id.tvMateriIsi)?.textSize = ukuranSp
            findViewById<TextView>(R.id.tvJadwalIsi)?.textSize = ukuranSp
            findViewById<TextView>(R.id.tvTugasIsi)?.textSize = ukuranSp

            if (::tvRingkasan.isInitialized) {
                tvRingkasan.text = RingkasanPengaturan.teks(this, settings)
            }
        }
    }
}
